// leitor.js

//TODO: importe o modulo fs 
const fs = require('fs');

//TODO: escreva a função o arquivo dados.txt
const conteudoInicial = 'Nome: João Silva\nIdade: 25 \nCidade: São Paulo \nProfissão: Desenvolvedor\n';

fs.writeFileSync('dados.txt', conteudoInicial);
console.log('Arquivo dados.txt criado!');

//TODO: Funçao paara ler arquivo 
function lerArquivo() {
    try {
        const dados = fs.readFileSync('dados.txt', 'utf-8');
    
        console.log('=== CONTEÚDO DO ARQUIVO ===');
        console.log(dados);
    
        const linhas = dados.split('\n');
        console.log(`Número de linhas: ${linhas.length}`)
    } catch (error) {
        console.error('Erro ao ler arquivo:', error.message)
    }
}

lerArquivo()
    